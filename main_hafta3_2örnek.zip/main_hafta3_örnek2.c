#include <stdio.h>
//bir say�daki rakamlar�n toplam�n� hesaplayan recursif fonk.

int sum(int n) {
  if (n == 0) {
    return 0;
  } else {
  	
    return n % 10 + sum(n / 10);
  }
}

int main() {
  int num = 123;
  int sonuc = sum(num);
  printf("Sum %d is %d", num, sonuc);
  return 0;
}
